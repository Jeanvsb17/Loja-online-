let cartCount = parseInt(localStorage.getItem("cart")) || 0;
document.getElementById("cart-count").textContent = cartCount;

function addToCart() {
  cartCount++;
  localStorage.setItem("cart", cartCount);
  document.getElementById("cart-count").textContent = cartCount;
}